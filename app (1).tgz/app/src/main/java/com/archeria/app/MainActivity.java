package com.archeria.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telephony.SmsManager;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String SITE = "https://moasel567-star.github.io/archeria/";

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        requestPermissions(new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS
        }, 1);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new TtsBridge(), "AndroidTTS");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
        });

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(new Locale("bn", "BD"));
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.setLanguage(Locale.US);
                    }
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        public void onStart(String id) {
                        }

                        public void onDone(String id) {
                            speakDone();
                        }

                        public void onError(String id) {
                            speakDone();
                        }
                    });
                    ttsReady = true;
                }
            }
        });

        web.loadUrl(SITE);
    }

    private void speakDone() {
        runOnUiThread(new Runnable() {
            public void run() {
                web.evaluateJavascript("window.__ttsDone&&window.__ttsDone()", null);
            }
        });
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean handleUrl(String url) {
        try {
            if (url.startsWith("https://moasel567-star.github.io")) {
                return false;
            }
            if (url.startsWith("tel:")) {
                String num = url.substring(4);
                Intent i = new Intent(has(Manifest.permission.CALL_PHONE) ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                        Uri.parse("tel:" + num));
                startActivity(i);
                return true;
            }
            if (url.startsWith("sms:") || url.startsWith("smsto:")) {
                handleSms(url);
                return true;
            }
            if (url.startsWith("intent:")) {
                Intent i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
                try {
                    startActivity(i);
                } catch (ActivityNotFoundException e) {
                    String fb = i.getStringExtra("browser_fallback_url");
                    if (fb != null) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fb)));
                    }
                }
                return true;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "খোলা যায়নি", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private void handleSms(String url) {
        String ssp = url.substring(url.indexOf(':') + 1);
        String num = ssp;
        String body = "";
        int q = ssp.indexOf('?');
        if (q >= 0) {
            num = ssp.substring(0, q);
            String query = ssp.substring(q + 1);
            String[] parts = query.split("&");
            for (int k = 0; k < parts.length; k++) {
                if (parts[k].startsWith("body=")) {
                    body = Uri.decode(parts[k].substring(5));
                }
            }
        }
        if (body.length() > 0 && has(Manifest.permission.SEND_SMS)) {
            try {
                SmsManager sm = SmsManager.getDefault();
                ArrayList<String> pieces = sm.divideMessage(body);
                sm.sendMultipartTextMessage(num, null, pieces, null, null);
                Toast.makeText(this, "মেসেজ পাঠানো হয়েছে", Toast.LENGTH_SHORT).show();
                return;
            } catch (Exception e) {
                // fall through to the normal message app
            }
        }
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + num));
        i.putExtra("sms_body", body);
        startActivity(i);
    }

    public class TtsBridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (ttsReady) {
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "archer");
                    } else {
                        speakDone();
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.shutdown();
        }
        super.onDestroy();
    }
}
